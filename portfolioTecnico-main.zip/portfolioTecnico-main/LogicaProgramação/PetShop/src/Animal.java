package petshop;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SESI_SENAI
 */
public class Animal {
    int matricula;
    String nome;
    String cor_pelagem;
    String genero;
    int idade;
    float peso;
    
}

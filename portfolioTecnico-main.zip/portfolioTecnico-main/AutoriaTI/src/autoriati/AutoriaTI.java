
package autoriati;

public class AutoriaTI {

    public static void main(String[] args) {
       Materias i = new Materias();
       i.setVisible(true);
    }
    
}
